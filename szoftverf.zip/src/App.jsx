import { useState } from 'react'
import './App.css'
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Programok from './Pages/Programok';
import Tipusok from './Pages/Tipusok';
import Nevjegy from './Pages/Nevjegy';
import Layout from './Pages/Layout';
import Notfound from './Pages/Notfound';

function App() {

  const router = createBrowserRouter([
    { element: <Layout />, children: [
      { path: "/", element: <Programok /> },
      { path: "/tipusok", element: <Tipusok /> },
      { path: "/programok", element: <Programok /> },
      { path: "/nevjegy", element: <Nevjegy /> },
      { path: "*", element: <Notfound /> }
    ]}
  ]);

  return (
    <div className='app'>
      <RouterProvider router={router} />
    </div>
  )
}

export default App
