import React from 'react'

export default function Nevjegy() {
  return (
    <div className='listan'>
        No névjegy nem volt nem is lesz! XD
    </div>
  )
}
