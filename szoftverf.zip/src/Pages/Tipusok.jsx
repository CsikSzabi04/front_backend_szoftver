import axios from 'axios';
import React from 'react'
import { useState } from 'react';
import { useEffect } from 'react';

export default function Tipusok() {

    const [tipusok, setTipusok] = useState([]);
    const [refresh, setRefresh] = useState(false);
  
    useEffect(() =>{
          async function getTipusok() {
              const resp = await fetch("http://localhost:88/tipusok");
              const json = await resp.json();
              setTipusok(json);
          }
          getTipusok();
    },[refresh]);

    async function onDel(id) {
        const response = await axios.delete("http://localhost:88/tipus/"+id);
        setRefresh(!refresh)
      }
  
    return (
      <div className='listap'>
          {tipusok.map((x,i) => <div className={'d'+(i%2)}>{x.tipus}  <span className='del'  onClick={() => onDel(x.taz)}>X</span></div>)}
      </div>
    )
  
}
