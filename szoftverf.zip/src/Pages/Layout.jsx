import React from 'react'
import { Link, Outlet } from 'react-router-dom'

export default function Layout() {
  return (
    <div className='app'>
        <div className='inp'>
            <Link to="/programok"> <input type="button" value="Programok" className='in'/></Link>
            <Link to="/tipusok"><input type="button" value="Típusok" className='in'/></Link>
            <Link to="/nevjegy"><input type="button" value="Névjegy" className='in a'/></Link>
        </div>
        <div className='lista'>
            <Outlet />
        </div>
        
    </div>
  )
}
