import React from 'react'

export default function Notfound() {
  return (
    <div className='app'>
        404 Page not Found
    </div>
  )
}
