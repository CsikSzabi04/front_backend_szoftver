import axios from 'axios';
import React from 'react'
import { useState } from 'react';
import { useEffect } from 'react';

export default function Programok() {
  const [programok, setProgramok] = useState([]);
  const [refresh, setRefresh] = useState(false);

  useEffect(() =>{
        async function getProgramok() {
            const resp = await fetch("http://localhost:88/programok");
            const json = await resp.json();
            setProgramok(json);
        }
        getProgramok();
  },[refresh]);

  async function onDel(id) {
    const response = await axios.delete("http://localhost:88/program/"+id);
    setRefresh(!refresh)
  }

  return (
    <div className='listap'>
        {programok.map((x,i) => <div className={'d'+(i%2)}>{x.nev} ({x.mega} MB) - {x.tipus} <span className='del' onClick={() => onDel(x.paz)}>X</span></div>)}
    </div>
  )
}
