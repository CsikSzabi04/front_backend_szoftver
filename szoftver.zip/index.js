import express from "express"
import cors from "cors"
import mysql from "mysql2/promise"

const  con = await mysql.createConnection({
    host: "localhost",
    port: 3306,
    database: "szoftver",
    user: "root",
    password: ""
});

const app = express()
app.use(express.json())
app.use(cors())

function verify(list){
    for(let i of list){
        if(!i) return false
    }
    return true
}

async function getProgramok(req, resp) {
    try {
        const [json] = await con.query("SELECT * FROM program INNER JOIN tipus USING(taz) ORDER BY(nev)")
        resp.send(json)
    } catch (error) {
        resp.send({"error" : error})
    }
}

async function getTipusok(req, resp) {
    try {
        const [json] = await con.query("SELECT * FROM tipus")
        resp.send(json)
    } catch (error) {
        resp.send({"error" : error})
    }
}

async function postProgram(req, resp) {
    try {
        if(!verify([req.body.nev, req.body.mega, req.body.taz])) resp.send({"error" : "Hibás paraméterek!"});
        else{
            const r = await con.query("INSERT INTO program (nev,mega,taz) VALUES(\""+req.body.nev+"\","+req.body.mega+","+req.body.taz+")")
            resp.send({"status" : "OK"})
        }
    } catch (error) {
        resp.send({"error" : error})
    }
}

async function deleteProgram(req, resp) {
    try {
        if(!req.params.paz) resp.send({"error" : "Hibás paraméterek!"});
        else{
            const [json] = await con.query("SELECT * FROM program WHERE paz="+req.params.paz)
            if(json.length < 1) resp.send({"error" : "Nem létező id!"});
            else{
                const r = await con.query("DELETE FROM program WHERE paz="+req.params.paz)
                resp.send({"status" : "OK"})
            }
        }
    } catch (error) {
        resp.send({"error" : error})
    }
}

async function postTipus(req, resp) {
    try {
        if(!verify([req.body.tipus])) resp.send({"error" : "Hibás paraméterek!"});
        else{
            const r = await con.query("INSERT INTO tipus (tipus) VALUES(\""+req.body.tipus+"\")")
            resp.send({"status" : "OK"})
        }
    } catch (error) {
        resp.send({"error" : error})
    }
}

async function deleteTipus(req, resp) {
    try {
        if(!req.params.taz) resp.send({"error" : "Hibás paraméterek!"});
        else{
            const [json] = await con.query("SELECT * FROM tipus WHERE taz="+req.params.taz)
            if(json.length < 1) resp.send({"error" : "Nem létező id!"});
            else{
                const [json] = await con.query("SELECT * FROM tipus INNER JOIN program USING(taz) WHERE taz="+req.params.taz)
                if(json.length < 1){
                    const r = await con.query("DELETE FROM tipus WHERE taz="+req.params.taz)
                    resp.send({"status" : "OK"})
                }else{
                    resp.send({"error" : "Nem törölhető, a típus használatban van!"})
                }
            }
        }
    } catch (error) {
        resp.send({"error" : error})
    }
}

app.get("/",(req, resp) => {resp.send("<h1>Szoftverek v1.0.0</h1>")})
app.get("/programok",getProgramok)
app.get("/tipusok",getTipusok)
app.post("/program",postProgram)
app.delete("/program/:paz",deleteProgram)
app.post("/tipus",postTipus)
app.delete("/tipus/:taz",deleteTipus)


app.listen(88, (e) => {if(e) console.log(e); else console.log("Server listening on port 88")})
